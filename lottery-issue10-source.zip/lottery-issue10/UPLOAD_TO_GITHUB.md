# GitHub 上傳說明（沒有原始儲存庫推送權限時）

目前連結的 GitHub 帳號為 `125689df`，對 `AlterChiu/20261009-gas-github-lottery-system` 僅有 `pull=true`、`push=false`。因此不能直接寫入其 `main`。

**建議透過 Fork + Pull Request：**

1. 在 <https://github.com/AlterChiu/20261009-gas-github-lottery-system> 點右上角 **Fork**，建立自己帳號下的 Fork。
2. 在自己的電腦上安裝 Git，於終端機執行：

```bash
git clone https://github.com/<你的 GitHub 帳號>/20261009-gas-github-lottery-system.git
cd 20261009-gas-github-lottery-system
git checkout -b issue-10-audit-log
```

3. 解壓本次提供的 ZIP，將 `app.js`、`index.html`、`style.css`、`gas/Code.gs`、`gas/README.md`、`tests/` 等複製覆蓋到上面 clone 出來的專案根目錄；保留原 repo 的其他檔案（例如 `presentation.md`）。
4. 執行 `node --test tests/*.test.cjs`，確認測試通過。
5. 提交及推送：

```bash
git add app.js index.html style.css gas/Code.gs gas/README.md tests README.md IMPLEMENTATION_PLAN.md IMPLEMENTATION_REPORT.md
git commit -m "feat: add persistent audit history for lottery operations (#10)"
git push -u origin issue-10-audit-log
```

6. 在 Fork 頁面按 **Contribute → Open pull request**，base 選 `AlterChiu/...:main`、compare 選你的 Fork `issue-10-audit-log`；貼上修改摘要與本機測試結果。

**注意：** 不要推送真正的 `LOTTERY_ADMIN_TOKEN`、含個資的 Google Sheets 備份或 GAS 授權憑證。GAS 部署程式碼要另外在 Apps Script 編輯器更新並重新部署新版本，GitHub Pages 推送不會自動更新 GAS Web App。
