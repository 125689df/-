# Issue #10 實作與驗收紀錄

- 原始專案：<https://github.com/AlterChiu/20261009-gas-github-lottery-system>
- 問題：<https://github.com/AlterChiu/20261009-gas-github-lottery-system/issues/10>
- 修改日期：2026-10-19
- 狀態：**原始碼實作完成、本機自動化測試通過；尚未在正式 GAS 環境部署驗證。**

## 修改摘要

| 檔案 | 實作變更 |
| --- | --- |
| `gas/Code.gs` | 加入經密鑰授權的 `doPost` API、事件追加、狀態重播、配額與資格驗證、LockService、冪等 actionId。 |
| `app.js` | 示範／正式模式隔離、正式伺服器抽獎、取消、重置、同步、操作歷程與 CSV 匯出。 |
| `index.html` | 新增管理員密鑰欄位、模式提示、歷程查詢與重新同步按鈕。 |
| `style.css` | 保留深色抽獎舞台的視覺方向並增加 Audit Log 與 RWD。 |
| `tests/*.test.cjs` | 無須外部測試依賴的 GAS 與前端模擬測試。 |
| `README.md`、`gas/README.md` | 部署與安全限制說明。 |

## 自動化驗收

2026-10-19 在本機使用 Node.js 執行以下命令：

```sh
node --check app.js
node --check < gas/Code.gs
node --test tests/*.test.cjs
```

測試覆蓋：未授權禁止存取、空紀錄初始化、正式抽獎、重播還原、重複請求冪等、獎項配額、不得重複中獎、取消並重抽、取消原因驗證、重置仍保留歷史、無效請求、前端展示模式抽獎取消與重置。

**結果：13 通過，0 失敗。**

## 尚未驗收／風險

1. GAS 真實 Google Sheets Web App 部署、GET／POST 的 CORS 跳轉與授權測試：**尚未驗證**。
2. 多位工作人員同時操作、網路逾時重送、Google Sheets 真實寫入限額：**需現場測試**。
3. 前端正式模式需要部署腳本並提供操作密鑰；不能將密鑰直接寫入公開 GitHub 檔案。
4. 受限於目前連結帳號對 `AlterChiu/...` 沒有 push 權限，因此程式包不代表已上傳至原作者的 repository。
5. 單一 shared token 不能代表驗證個人身分，actor 記為 unknown；Google Sheets 編輯權限持有人仍可修改日誌。

## 現場展示步驟

1. 開啟 `index.html`；確認 `展示模式`。
2. 按抽獎，看到 `DRAW`。
3. 在中獎清單按「取消」，填原因，看到 `CANCEL`，獎項名額回復。
4. 再抽一次，看到新 `DRAW`。
5. 按「重置紀錄」，填原因，看到 `RESET`；中獎名單清空但歷程仍在。
6. 重新整理，展示歷程仍在（localStorage）；**正式跨裝置歷程須另外部署 GAS 測試**。
