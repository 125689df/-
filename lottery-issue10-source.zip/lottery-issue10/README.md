# 活動幸運抽獎系統 2.0 — Issue #10 操作歷程

基於 [AlterChiu/20261009-gas-github-lottery-system](https://github.com/AlterChiu/20261009-gas-github-lottery-system) 設計的 Issue #10 教學實作版本。保留 GitHub Pages、Google Apps Script、Google Sheets 及展示抽獎介面，增加 `DRAW`、`CANCEL`、`RESET` 的歷程紀錄。

> **狀態**：本專案為可部署原始碼，通過本機測試；Google Apps Script 正式部署、跨域 POST 與多瀏覽器實際連線需由有試算表權限的人完成並驗收。未經部署驗證前不可宣稱為生產環境安全抽獎系統。

## 功能與技術設計

- **正式模式**：前端只顯示動畫，抽獎名額、資格與中獎人由 GAS 後端確認。取消單筆中獎須填原因；重置時歷史不刪除。
- **AuditLogs**：GAS 自動建立 `AuditLogs` 工作表；每次正式操作只新增一列事件，`winners` 由事件重播推導，減少多表寫入不一致。
- **存取權限**：`doPost()` 的正式操作與讀取歷程需要 Script Properties `LOTTERY_ADMIN_TOKEN`，操作密鑰絕不寫進靜態程式碼、GitHub 或 URL。單一共用密鑰無法認證個別工作人員，歷程標記 `actor=unknown`。
- **併發與冪等**：用 `LockService` 鎖住重播、檢查與事件新增，用 `actionId` 避免相同要求重複提交。
- **隱私**：事件僅儲存參加者 ID、獎項 ID 與狀態，不額外記錄電子郵件或姓名。原始 GET 介面仍包含學員資訊，正式部署必須審視公開程度。
- **展示模式**：不需要 GAS 即可測試，紀錄與正式模式嚴格隔離，僅在本機 `localStorage`；不代表可稽核或跨裝置同步。
- **歷程檢視**：網頁顯示最近 200 筆事件，完整操作歷程仍在試算表 `AuditLogs` 中。

## 目錄

```
index.html          # 網頁 UI
style.css           # 原版深色風格延伸
app.js              # 前端動畫、展示模式、正式模式、歷程列表
 gas/Code.gs        # Google Apps Script 可信任操作與持久化歷程
 gas/README.md      # GAS 部署步驟與安全提醒
 tests/gas.test.cjs # 在 Node.js 模擬 Google Sheets 的測試
 IMPLEMENTATION_PLAN.md # G01 原規劃文件（規劃階段，不代表驗收已完成）
```

## 快速開始

1. 先用瀏覽器開啟 `index.html` → **載入展示資料**，抽獎、取消、重置後可在操作歷程看到事件（僅本機）。
2. 建立 Google Sheet：`表單回應 1`（欄名至少包含 `姓名`、`學號`）、`獎品設定`（至少 `獎品名稱`、`配額`）。
3. 在 Apps Script 編輯器貼入 `gas/Code.gs`，設定 Script Properties 的 `LOTTERY_ADMIN_TOKEN`，至少 24 位且隨機；獨立腳本另設 `SPREADSHEET_ID`。
4. 部署成 Web App，執行身分設定成擁有試算表存取權的帳號；跨域靜態頁通常需要將 Web App 的存取設定為 `Anyone`。**所以必須使用長度足夠且未外洩的操作密鑰**；開放的 `doGet` 可能公開參加者資訊，禁止直接使用未經同意的個人資料。
5. 在 `index.html` 的設定頁輸入完整 `/exec` URL 與操作密鑰，按下「連線正式模式」。瀏覽器需要支援 HTTPS、Web Crypto API 和 GAS 跨域回傳；若 CORS 重導向阻擋 POST，需部署受控的中繼 API 或同源網頁，**不能改成不驗證的 GET 寫入來規避**。
6. 在正式模式按下抽獎、取消或重置，再重新整理和跨瀏覽器同步，確認 `AuditLogs` 保留歷程。

## 已知限制

- Google Sheets 擁有者／編輯者仍可以直接更改 `AuditLogs`，不符合正式防竄改稽核要求。
- 單一密鑰只能驗證「持有密鑰」，無法確定個別操作者；無可靠身分驗證時顯示 `unknown`。
- 原版 `prize_行號` 與無學號時的 `s_行號` 識別碼依賴工作表行序；活動開始後**不要插入、刪除或重新排序**正式獎項／名冊。生產使用應改為不可變 UUID。
- GAS 使用 `Math.random()` 後端選人，無可供第三方驗證的抽獎種子與密碼學公平性證明。
- `AuditLogs` 應限制工作表編輯權限，並按法規及活動規範設定保留期限。代碼不會自動刪除歷程。
- 展示與正式模式是兩套隔離紀錄，不能將原版既有 `localStorage` 中獎名單當作已驗證的後端抽獎紀錄。

## 測試

```bash
node --check app.js
node --check < gas/Code.gs
node --test tests/*.test.cjs
```

測試涵蓋：抽獎、重複提交、重抽（取消後）、重置仍保留事件、配額、防止重複得獎、未授權阻擋、歷史查詢。

## GitHub 協作

原始儲存庫 `AlterChiu/...` 為他人持有。若帳號沒有 push 權限：先 Fork 到自己的 GitHub，再以 `issue-10-audit-log` 分支提交，建立 Pull Request 指向原作者 main。**請勿在 GitHub 提交 Script Properties 中的密鑰或真實學生資料。**
