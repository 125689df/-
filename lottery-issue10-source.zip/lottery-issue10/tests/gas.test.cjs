const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

class Sheet {
  constructor(name, rows=[]) { this.name=name;this.rows=rows.map(r=>[...r]);this.frozen=0; }
  getDataRange(){return {getValues:()=>this.rows.map(r=>[...r])};}
  getLastRow(){return this.rows.length;}
  getRange(row,col,nrows,ncols){return {getValues:()=>this.rows.slice(row-1,row-1+nrows).map(r=>Array.from({length:ncols},(_,i)=>r[col-1+i]||''))};}
  appendRow(row){this.rows.push([...row]);}
  setFrozenRows(n){this.frozen=n;}
}
class Book {
  constructor(){this.sheets={
    '獎品設定':new Sheet('獎品設定', [['獎品名稱','配額'],['頭獎',1],['二獎',2]]),
    '表單回應 1':new Sheet('表單回應 1', [['姓名','學號','系所','年級'],['甲','a','資工','大一'],['乙','b','資訊','大二'],['丙','c','商管','大三']])
  };}
  getSheetByName(name){return this.sheets[name]||null;}
  getSheets(){return Object.values(this.sheets);}
  insertSheet(name){this.sheets[name]=new Sheet(name);return this.sheets[name];}
}
function harness(){
  const book=new Book();let seq=0;
  const sandbox={
    ContentService:{MimeType:{JSON:'json'},createTextOutput(content){return {content,setMimeType(){return this;}}}},
    PropertiesService:{getScriptProperties(){return {getProperty(key){return key==='LOTTERY_ADMIN_TOKEN'?'this_is_an_extremely_long_token_for_testing':'';}}}},
    LockService:{getScriptLock(){return {waitLock(){},releaseLock(){}}}},
    SpreadsheetApp:{getActiveSpreadsheet(){return book;},flush(){}},
    Utilities:{getUuid(){return 'event-'+(++seq);}},
    console,Math,Date,JSON,Object,String,Array,Set
  };
  const code=fs.readFileSync(path.join(__dirname,'../gas/Code.gs'),'utf8');
  vm.runInNewContext(code,sandbox);
  function request(action,more={}){
    return JSON.parse(sandbox.doPost({postData:{contents:JSON.stringify({token:'this_is_an_extremely_long_token_for_testing',action,...more})}}).content);
  }
  const events=()=>book.getSheetByName('AuditLogs')?.rows.slice(1)||[];
  return {book,request,events,doPost:sandbox.doPost,doGet:sandbox.doGet};
}
const id=i=>'unique-action-id-'+i;

test('unauthorized POST is rejected and cannot create AuditLogs',()=>{
  const h=harness();const result=JSON.parse(h.doPost({postData:{contents:JSON.stringify({action:'draw',actionId:id(1),prizeId:'prize_1',token:'wrong'})}}).content);
  assert.equal(result.status,'error');assert.equal(h.book.getSheetByName('AuditLogs'),null);
});
test('authorized snapshot makes empty audit sheet and keeps public GET compatible',()=>{
  const h=harness();const initial=JSON.parse(h.doGet({}).content);
  assert.equal(initial.prizes.length,2);assert.equal(initial.participants.length,3);
  const r=h.request('snapshot');assert.equal(r.status,'success');assert.equal(r.winners.length,0);
  assert.equal(h.events().length,0);
});
test('draw is authoritative, retains event and replays winner on snapshot',()=>{
  const h=harness();const r=h.request('draw',{actionId:id(1),prizeId:'prize_1',winnerId:'FORGED'});
  assert.equal(r.status,'success');assert.equal(r.winners.length,1);
  assert.notEqual(r.winners[0].winnerId,'FORGED');assert.equal(r.lastEvent.eventType,'DRAW');
  assert.equal(r.lastEvent.actor,'unknown');
  assert.equal(h.request('snapshot').winners[0].winnerId,r.winners[0].winnerId);
  assert.equal(h.events().length,1);
});
test('duplicate actionId is idempotent and does not add events',()=>{
  const h=harness();const r1=h.request('draw',{actionId:id(1),prizeId:'prize_1'});
  const r2=h.request('draw',{actionId:id(1),prizeId:'prize_1'});
  assert.equal(r2.duplicate,true);assert.equal(r2.lastEvent.eventId,r1.lastEvent.eventId);assert.equal(h.events().length,1);
});
test('quota stops additional draws',()=>{
  const h=harness();h.request('draw',{actionId:id(1),prizeId:'prize_1'});
  const r=h.request('draw',{actionId:id(2),prizeId:'prize_1'});
  assert.equal(r.status,'error');assert.match(r.message,/名額/);assert.equal(h.events().length,1);
});
test('same participant cannot win two prizes simultaneously',()=>{
  const h=harness();h.request('draw',{actionId:id(1),prizeId:'prize_1'});
  const winner=h.request('draw',{actionId:id(2),prizeId:'prize_2'});
  assert.equal(winner.status,'success');
  assert.equal(new Set(winner.winners.map(w=>w.winnerId)).size,2);
});
test('cancel keeps original draw, frees quota and allows redraw',()=>{
  const h=harness();const r=h.request('draw',{actionId:id(1),prizeId:'prize_1'});
  const cancelled=h.request('cancel',{actionId:id(2),drawEventId:r.lastEvent.eventId,reason:'資格不符'});
  assert.equal(cancelled.status,'success');assert.equal(cancelled.winners.length,0);assert.equal(h.events().length,2);
  assert.equal(cancelled.history[0].reason,'資格不符');
  const redrawn=h.request('draw',{actionId:id(3),prizeId:'prize_1'});
  assert.equal(redrawn.winners.length,1);assert.equal(h.events().length,3);
});
test('cancel without reason or cancelled draw id is rejected',()=>{
  const h=harness();const draw=h.request('draw',{actionId:id(1),prizeId:'prize_1'});
  assert.equal(h.request('cancel',{actionId:id(2),drawEventId:draw.lastEvent.eventId}).status,'error');
  h.request('cancel',{actionId:id(3),drawEventId:draw.lastEvent.eventId,reason:'資格不符'});
  assert.equal(h.request('cancel',{actionId:id(4),drawEventId:draw.lastEvent.eventId,reason:'again'}).status,'error');
  assert.equal(h.events().length,2);
});
test('reset keeps old events and allows fresh draw',()=>{
  const h=harness();h.request('draw',{actionId:id(1),prizeId:'prize_1'});
  const reset=h.request('reset',{actionId:id(2),reason:'重新開獎'});
  assert.equal(reset.winners.length,0);assert.equal(reset.history.length,2);
  assert.equal(reset.history[0].eventType,'RESET');assert.equal(reset.history[1].eventType,'DRAW');
  assert.equal(h.request('draw',{actionId:id(3),prizeId:'prize_1'}).winners.length,1);
});
test('incorrect actionId cannot mutate state',()=>{
  const h=harness();const r=h.request('draw',{actionId:'x',prizeId:'prize_1'});
  assert.equal(r.status,'error');assert.equal(h.events().length,0);
});

test('spreadsheet formula prefixes in reason are rejected',()=>{
  const h=harness();const draw=h.request('draw',{actionId:id(1),prizeId:'prize_1'});
  const x=h.request('cancel',{actionId:id(2),drawEventId:draw.lastEvent.eventId,reason:'=IMPORTXML("url")'});
  assert.equal(x.status,'error');assert.equal(h.events().length,1);
});
