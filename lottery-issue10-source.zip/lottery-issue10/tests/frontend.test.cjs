const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const {webcrypto}=require('node:crypto');

class FakeElement {
  constructor(tag='div') {this.tag=tag;this.children=[];this.events={};this.textContent='';this.className='';this.value='';this.disabled=false;this.classList={add(){},remove(){},toggle(){}};}
  replaceChildren(...children){this.children=[...children];if(this.tag==='select')this.value=this.children[0]?.value||'';}
  append(...children){this.children.push(...children);}
  appendChild(child){this.append(child);return child;}
  remove(){}
  setAttribute(){}
  addEventListener(type,cb){this.events[type]=cb;}
  trigger(type){return this.events[type]?.({target:this});}
}
function setup(){
  const nodes=new Map();
  const ids=['config-panel','api-status-message','notice','mode-label','gas-api-url','gas-admin-token','btn-fetch-data','prize-select','stat-total-quota','stat-drawn-count','stat-remaining-quota','prize-desc','btn-draw','btn-reset-lottery','btn-refresh-history','rolling-display','winners-list-container','audit-list','history-filter','history-info','btn-toggle-config','btn-close-config','btn-load-demo','btn-export-csv'];
  for(const id of ids)nodes.set(id,new FakeElement(id.includes('select')||id.includes('filter')?'select':'div'));
  const selectors=new Map(['.stage-placeholder','.winner-candidate-name','.winner-candidate-meta'].map(k=>[k,new FakeElement()]));
  const data=new Map();
  const localStorage={getItem:k=>data.get(k)||null,setItem:(k,v)=>data.set(k,v),removeItem:k=>data.delete(k)};
  const document={readyState:'complete',getElementById:id=>nodes.get(id),querySelector:s=>selectors.get(s),createElement:t=>new FakeElement(t),body:new FakeElement('body')};
  const window={crypto:webcrypto,prompt:()=> '資格不符',confirm:()=>true};
  const context={document,window,localStorage,Blob,URL,console,setTimeout,clearTimeout,Date,Math,JSON,Set,Array,Uint8Array};
  vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../app.js'),'utf8'),context);
  return {nodes,state:window.__lotterySystem.state,data};
}
test('frontend loads original demo prizes and displays demo warning',()=>{
  const {nodes,state}=setup();
  assert.equal(state.mode,'demo');assert.equal(state.prizes.length,4);
  assert.equal(state.participants.length,15);
  assert.match(nodes.get('mode-label').textContent,/展示模式/);
  assert.equal(nodes.get('btn-draw').disabled,false);
});
test('frontend demo DRAW, CANCEL, RESET history survives state reset',async()=>{
  const {nodes,state}=setup();
  await nodes.get('btn-draw').trigger('click');
  assert.equal(state.winners.length,1);assert.equal(state.history[0].eventType,'DRAW');
  const drawEvent=state.winners[0].drawEventId;
  const winnerRow=nodes.get('winners-list-container').children[0].children[1];
  await winnerRow.children[1].trigger('click');
  assert.equal(state.winners.length,0);assert.equal(state.history[0].eventType,'CANCEL');
  assert.equal(state.history[1].eventId,drawEvent);
  await nodes.get('btn-draw').trigger('click');
  assert.equal(state.winners.length,1);
  await nodes.get('btn-reset-lottery').trigger('click');
  assert.equal(state.winners.length,0);
  assert.deepEqual(Array.from(state.history.slice(0,2).map(x=>x.eventType)),['RESET','DRAW']);
  assert.ok(state.history.length>=4);
});
