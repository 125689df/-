/**
 * Lucky Draw 2.0 / Issue #10 - authoritative, append-only event history.
 * Google Apps Script Web App: deploy as owner; only HTTPS POST with admin token may read
 * audit/history or mutate official lottery state. NEVER put the token in GitHub Pages code.
 * NOTE: this is an operational history, not tamper-evident forensic logging.
 */
const CONFIG = {
  PRIZE_SHEET_NAMES: ['獎品設定', '獎品清單', 'Prizes', 'Prize'],
  PARTICIPANT_SHEET_NAMES: ['表單回應 1', '表單回應', 'Form Responses 1', 'Form Responses', '參加名單', 'Participants'],
  EVENT_SHEET: 'AuditLogs',
  EVENT_HEADERS: ['eventId', 'timestamp', 'actionId', 'eventType', 'prizeId', 'winnerId', 'beforeState', 'afterState', 'actor', 'reason', 'metadataJson'],
  HISTORY_LIMIT: 200
};

function createJsonResponse(data) {
  return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);
}

/** Legacy public read-only GET interface. IMPORTANT: participants may contain PII. */
function doGet(e) {
  try {
    const data = getLotteryData();
    return createJsonResponse({status: 'success', timestamp: new Date().toISOString(), prizes: data.prizes, participants: data.participants});
  } catch (err) {
    return createJsonResponse({status: 'error', message: String(err.message || err), prizes: [], participants: []});
  }
}

/** JSON body, sent as text/plain to avoid cross-origin preflight from GitHub Pages. */
function doPost(e) {
  let lock;
  try {
    const raw = (e && e.postData && e.postData.contents) || '{}';
    if (raw.length > 8192) throw new Error('請求內容過大');
    const req = JSON.parse(raw);
    const secret = PropertiesService.getScriptProperties().getProperty('LOTTERY_ADMIN_TOKEN');
    if (!secret || secret.length < 24) throw new Error('尚未設定安全的 LOTTERY_ADMIN_TOKEN');
    if (typeof req.token !== 'string' || req.token !== secret) throw new Error('無權執行此操作');
    const action = String(req.action || '');
    if (!['snapshot', 'draw', 'cancel', 'reset'].includes(action)) throw new Error('不支援的操作');

    lock = LockService.getScriptLock();
    lock.waitLock(20000);
    const ss = getTargetSpreadsheet();
    const sheet = getAuditSheet_(ss);
    const events = readAuditEvents_(sheet);
    const data = getLotteryData();
    let lastEvent = null;
    let duplicate = false;

    if (action !== 'snapshot') {
      const actionId = String(req.actionId || '');
      if (!/^[a-zA-Z0-9_-]{12,100}$/.test(actionId)) throw new Error('actionId 格式錯誤');
      const oldEvent = events.find(ev => ev.actionId === actionId);
      if (oldEvent) {
        if (oldEvent.eventType !== action.toUpperCase()) throw new Error('actionId 已被另一種操作使用');
        lastEvent = oldEvent;
        duplicate = true;
      } else {
        const active = replayEvents_(events);
        const now = new Date().toISOString();
        const next = {
          eventId: Utilities.getUuid(), timestamp: now, actionId,
          eventType: action.toUpperCase(), prizeId: '', winnerId: '',
          beforeState: '', afterState: '', actor: 'unknown', reason: '', metadataJson: '{}'
        };
        if (action === 'draw') {
          const prize = data.prizes.find(p => p.id === String(req.prizeId || ''));
          if (!prize) throw new Error('獎項不存在');
          const used = Object.values(active);
          const count = used.filter(w => w.prizeId === prize.id).length;
          if (count >= prize.quota) throw new Error('此獎項已無剩餘名額');
          const usedIds = new Set(Object.keys(active));
          const pool = data.participants.filter(p => p.id && !usedIds.has(p.id));
          if (!pool.length) throw new Error('已無符合資格的參加者');
          // Server-side choice, never trust a browser-submitted winnerId.
          const winner = pool[Math.floor(Math.random() * pool.length)];
          next.prizeId = prize.id;
          next.winnerId = winner.id;
          next.beforeState = 'NOT_WON';
          next.afterState = 'DRAWN';
        } else if (action === 'cancel') {
          const drawEventId = String(req.drawEventId || '');
          const winner = Object.values(active).find(w => w.drawEventId === drawEventId);
          if (!winner) throw new Error('找不到有效的中獎紀錄，可能已取消或重置');
          next.prizeId = winner.prizeId;
          next.winnerId = winner.winnerId;
          next.beforeState = 'DRAWN';
          next.afterState = 'CANCELLED';
          next.reason = String(req.reason || '').trim().slice(0, 200);
          if (!next.reason) throw new Error('取消中獎請填寫原因');
          if (/^\s*[=+\-@]/.test(next.reason)) throw new Error('原因不可包含試算表公式前綴');
          next.metadataJson = JSON.stringify({drawEventId});
        } else if (action === 'reset') {
          const size = Object.keys(active).length;
          if (!size) throw new Error('目前沒有可重置的中獎紀錄');
          next.beforeState = 'ACTIVE:' + size;
          next.afterState = 'ACTIVE:0';
          next.reason = String(req.reason || '').trim().slice(0, 200);
          if (!next.reason) throw new Error('重置抽獎請填寫原因');
          if (/^\s*[=+\-@]/.test(next.reason)) throw new Error('原因不可包含試算表公式前綴');
          next.metadataJson = JSON.stringify({affectedCount: size});
        }
        // Single append is the only authoritative state mutation; replay derives winners.
        // Sheet editor rights can still alter rows; this is not a tamper-proof audit trail.
        sheet.appendRow(CONFIG.EVENT_HEADERS.map(h => next[h]));
        SpreadsheetApp.flush();
        events.push(next);
        lastEvent = next;
      }
    }
    const result = snapshot_(data, events);
    return createJsonResponse(Object.assign({status: 'success', duplicate, lastEvent}, result));
  } catch (err) {
    return createJsonResponse({status: 'error', message: String(err.message || err)});
  } finally {
    if (lock) { try { lock.releaseLock(); } catch (_) {} }
  }
}

function getAuditSheet_(ss) {
  let sheet = ss.getSheetByName(CONFIG.EVENT_SHEET);
  if (!sheet) {
    sheet = ss.insertSheet(CONFIG.EVENT_SHEET);
    sheet.appendRow(CONFIG.EVENT_HEADERS);
    sheet.setFrozenRows(1);
  } else {
    const found = sheet.getRange(1, 1, 1, CONFIG.EVENT_HEADERS.length).getValues()[0];
    if (found.join('|') !== CONFIG.EVENT_HEADERS.join('|')) throw new Error('AuditLogs 欄位與目前版本不相符');
  }
  return sheet;
}

function readAuditEvents_(sheet) {
  const n = sheet.getLastRow();
  if (n <= 1) return [];
  return sheet.getRange(2, 1, n - 1, CONFIG.EVENT_HEADERS.length).getValues().map(row => {
    const ev = {};
    CONFIG.EVENT_HEADERS.forEach((key, i) => {
      const value = row[i];
      ev[key] = value instanceof Date ? value.toISOString() : String(value == null ? '' : value);
    });
    return ev;
  }).filter(x => x.eventId);
}

/** Replay from the append-only source of truth. No separate mutable winner table. */
function replayEvents_(events) {
  const active = {};
  events.forEach(ev => {
    if (ev.eventType === 'DRAW') {
      active[ev.winnerId] = {winnerId: ev.winnerId, prizeId: ev.prizeId, timestamp: ev.timestamp, drawEventId: ev.eventId};
    } else if (ev.eventType === 'CANCEL') {
      let meta = {};
      try { meta = JSON.parse(ev.metadataJson || '{}'); } catch (_) {}
      if (active[ev.winnerId] && active[ev.winnerId].drawEventId === meta.drawEventId) delete active[ev.winnerId];
    } else if (ev.eventType === 'RESET') {
      Object.keys(active).forEach(id => delete active[id]);
    }
  });
  return active;
}

function snapshot_(data, events) {
  const participantMap = Object.fromEntries(data.participants.map(p => [p.id, p]));
  const prizeMap = Object.fromEntries(data.prizes.map(p => [p.id, p]));
  const winners = Object.values(replayEvents_(events)).map(w => {
    const p = participantMap[w.winnerId] || {};
    const prize = prizeMap[w.prizeId] || {};
    return Object.assign({}, w, {name: p.name || '(名冊已變更)', department: p.department || '', grade: p.grade || '', email: p.email || '', prizeName: prize.name || w.prizeId});
  });
  // UI shows the latest 200; the complete event log remains in Google Sheets.
  const recent = events.slice(-CONFIG.HISTORY_LIMIT).reverse().map(ev => Object.assign({}, ev, {
    prizeName: prizeMap[ev.prizeId] ? prizeMap[ev.prizeId].name : ev.prizeId,
    winnerName: participantMap[ev.winnerId] ? participantMap[ev.winnerId].name : ''
  }));
  return {winners, history: recent, historyTotal: events.length, historyLimit: CONFIG.HISTORY_LIMIT};
}

function getTargetSpreadsheet() {
  let ss = null;
  try { ss = SpreadsheetApp.getActiveSpreadsheet(); } catch (_) {}
  if (ss) return ss;
  const id = PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
  if (id) return SpreadsheetApp.openById(id);
  throw new Error('無法取得試算表，請設定 SPREADSHEET_ID');
}

function findSheet(ss, candidateNames, fallbackToIndex) {
  for (const name of candidateNames) {
    const sheet = ss.getSheetByName(name);
    if (sheet) return sheet;
  }
  const sheets = ss.getSheets();
  return fallbackToIndex >= 0 && sheets.length > fallbackToIndex ? sheets[fallbackToIndex] : null;
}

function getLotteryData() {
  const ss = getTargetSpreadsheet();
  const prizeSheet = findSheet(ss, CONFIG.PRIZE_SHEET_NAMES, -1);
  const participantSheet = findSheet(ss, CONFIG.PARTICIPANT_SHEET_NAMES, 0);
  const prizes = parsePrizes(prizeSheet ? prizeSheet.getDataRange().getValues() : []);
  const participants = parseParticipants(participantSheet ? participantSheet.getDataRange().getValues() : []);
  return {prizes, participants};
}

function parsePrizes(rows) {
  if (!rows || rows.length < 2) return [];
  const headers = rows[0].map(h => String(h || '').trim());
  const nameIndex = findColumnIndex(headers, ['獎品名稱', '獎項名稱', '獎品', '名稱', 'Prize', 'Name']);
  const quotaIndex = findColumnIndex(headers, ['配額', '數量', '總數', '名額', 'Quota', 'Count', 'Quantity']);
  const orderIndex = findColumnIndex(headers, ['順序', '抽獎順序', 'Order', 'Sort']);
  const descIndex = findColumnIndex(headers, ['說明', '備註', 'Description', 'Desc']);
  return rows.slice(1).map((row, idx) => {
    if (isRowEmpty(row)) return null;
    const name = String((nameIndex >= 0 ? row[nameIndex] : row[0]) || '').trim();
    if (!name) return null;
    const quota = Math.max(0, parseInt(quotaIndex >= 0 ? row[quotaIndex] : 1, 10) || 0);
    const order = parseInt(orderIndex >= 0 ? row[orderIndex] : idx + 1, 10) || idx + 1;
    return {id: 'prize_' + (idx + 1), name, quota, order, description: descIndex >= 0 ? String(row[descIndex] || '') : ''};
  }).filter(Boolean).sort((a,b) => a.order - b.order);
}

function parseParticipants(rows) {
  if (!rows || rows.length < 2) return [];
  const headers = rows[0].map(h => String(h || '').trim());
  const nameIndex = findColumnIndex(headers, ['姓名', '學生姓名', '中文姓名', '名字', 'Name', 'Full Name']);
  const deptIndex = findColumnIndex(headers, ['系所', '科系', '學系', '系別', '院系', '部門', '組別', '單位', 'Department', 'Dept', 'Major']);
  const gradeIndex = findColumnIndex(headers, ['年級', '年級別', '年級(如大一/大二)', 'Grade', 'Year']);
  const idIndex = findColumnIndex(headers, ['學號', '學生證號', '員工編號', '工號', '編號', 'ID', 'Student ID', 'Employee ID']);
  const emailIndex = findColumnIndex(headers, ['電子郵件', '學校信箱', 'Email', '信箱']);
  const usedIds = new Set();
  return rows.slice(1).map((row, idx) => {
    if (isRowEmpty(row)) return null;
    const name = String((nameIndex >= 0 ? row[nameIndex] : row[1] || row[0]) || '').trim();
    if (!name) return null;
    const id = String((idIndex >= 0 ? row[idIndex] : '') || '').trim() || 's_' + (idx + 1);
    // Avoid writing formula-like identifiers into the audit sheet.
    if (/^[\s]*[=+\-@]/.test(id)) return null;
    if (usedIds.has(id)) return null;
    usedIds.add(id);
    return {id, name, department: deptIndex >= 0 ? String(row[deptIndex] || '') : '', grade: gradeIndex >= 0 ? String(row[gradeIndex] || '') : '', email: emailIndex >= 0 ? String(row[emailIndex] || '') : ''};
  }).filter(Boolean);
}

function findColumnIndex(headers, keys) {
  return headers.findIndex(header => keys.some(key => String(header).toLowerCase() === key.toLowerCase()));
}

function isRowEmpty(row) {
  return !row || row.every(v => String(v == null ? '' : v).trim() === '');
}
