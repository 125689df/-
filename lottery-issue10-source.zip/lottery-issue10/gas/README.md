# GAS 後端：AuditLogs 操作歷程

1. 建立 Google Sheets，包含 `獎品設定`、`表單回應 1` 分頁（沿用原專案原有欄位格式）。
2. 在「擴充功能 → Apps Script」貼上 `Code.gs`。
3. 專案設定 → 指令碼屬性（Script Properties）新增 `LOTTERY_ADMIN_TOKEN`，例如先以密碼管理器產生 **32 bytes 以上的隨機字串**。請勿將實際 token 硬編碼到 GitHub Pages、README、CSV 或 URL。若是獨立 GAS 專案，再設定 `SPREADSHEET_ID`。
4. 部署 → 新增部署作業 → 網路應用程式（Web App）。執行身分設為擁有工作表權限的帳號。原專案以 `Anyone` 對前端跨網域提供 GET，使用本版本時，必須評估參加者個資與公開名冊的風險；有需要請改成受控的中繼 API／同源應用。
5. 在網頁的「設定 API」輸入完整 `/exec` URL 與 token。前端以 `text/plain` POST 包裝 JSON；GAS 的跨域重導向在不同部署設定下可能遇到 CORS 問題，請在目標域名實測。不要把變更狀態的操作改成無驗證 GET。
6. 點「連線正式模式」，首次成功時程式會在原試算表自動新增 `AuditLogs` 與固定欄名。
7. 用兩個瀏覽器登入正式模式測試抽獎、取消、重置與重新讀取。檢查每次事件只新增一列且保存於伺服器。

## JSON API

`GET /exec`：讀取獎品及名冊（沿用原版，不含機密歷程）。

`POST /exec`：`Content-Type: text/plain;charset=UTF-8`，JSON：

```json
{"token":"<從 Script Properties 設定，勿上傳>","action":"snapshot"}
```

```json
{"token":"<token>","action":"draw","actionId":"random-unique-request-id-001","prizeId":"prize_1"}
```

```json
{"token":"<token>","action":"cancel","actionId":"random-unique-request-id-002","drawEventId":"<DRAW 事件 ID>","reason":"未領獎"}
```

```json
{"token":"<token>","action":"reset","actionId":"random-unique-request-id-003","reason":"主持人宣布重新抽獎"}
```

成功回傳 `status=success`、`winners`、`history`、`historyTotal`、`lastEvent`；錯誤回傳 `status=error`。同一 actionId 重送時回傳 `duplicate=true`，不再次寫入。

## 欄位與隱私

`eventId,timestamp,actionId,eventType,prizeId,winnerId,beforeState,afterState,actor,reason,metadataJson`。

事件僅存必要識別碼與原因；拒絕寫入自由指定的 `actor`。因為使用共用操作密鑰，`actor` 固定 `unknown`。正式稽核需搭配個人登入與伺服器驗證。

**正式環境注意：** Sheets 編輯者可篡改歷程；`AuditLogs` 並非不可變儲存體。安排每日備份、權限限制與保留政策。Web App 不應對公眾揭露私人名冊。
