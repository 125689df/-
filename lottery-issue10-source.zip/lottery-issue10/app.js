/** Lucky Draw / Issue #10: official draws are executed by GAS, not the browser. */
(() => {
  'use strict';
  const KEYS = {url:'lottery_gas_api_url', demo:'lottery_issue10_demo'};
  const DEMO_DATA = {
    prizes: [
      {id:'demo_p1',name:'頭獎：Apple iPad Air (256GB)',quota:1,order:1,description:'特獎校園高效學習首選'},
      {id:'demo_p2',name:'二獎：Sony 降噪藍牙耳機',quota:2,order:2,description:'專注讀書聽歌神器'},
      {id:'demo_p3',name:'三獎：校園書局與百貨禮券 $2000',quota:5,order:3,description:'購書文具實用好禮'},
      {id:'demo_p4',name:'幸運獎：星巴克飲品兌換券',quota:10,order:4,description:'期中期末暖心咖啡'}
    ],
    participants: [
      ['B11902001','陳冠宇','資訊工程學系','大三'],['B12703015','林若晴','財務金融學系','大二'],
      ['B10102033','張凱翔','外國語文學系','大四'],['B13501008','黃子庭','生物機電學系','大一'],
      ['R12521019','吳家瑋','電機工程研究所','碩二'],['B11201042','許雅筑','歷史學系','大三'],
      ['B12901024','楊宗翰','土木工程學系','大二'],['B10302011','蔡欣妤','化學工程學系','大四'],
      ['B13105022','劉宇恆','中國文學系','大一'],['B11602017','周佩穎','社會學系','大三'],
      ['B12304005','鄭兆廷','機械工程學系','大二'],['B10902050','謝宜萱','醫學系','大四'],
      ['B13801016','郭哲銘','法律學系','大一'],['R13622003','曾詩婷','經濟學研究所','碩一'],
      ['B11401039','梁詠晴','心理學系','大三']
    ].map(([id,name,department,grade])=>({id,name,department,grade,email:''}))
  };
  const state = {mode:'demo',apiUrl:'',token:'',prizes:[],participants:[],currentPrizeId:'',winners:[],history:[],historyTotal:0,historyLimit:200,busy:false,pendingDraw:null};
  const $ = id => document.getElementById(id);
  const el = {};
  const sleep = ms => new Promise(resolve => setTimeout(resolve,ms));
  const safe = x => String(x == null ? '' : x);
  const formatTime = s => s ? new Date(s).toLocaleString('zh-TW',{hour12:false}) : '-';
  const uuid = () => {
    if (window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID().replace(/-/g,'');
    if (window.crypto && typeof window.crypto.getRandomValues === 'function') {
      const a = new Uint8Array(16); window.crypto.getRandomValues(a);
      return Array.from(a, x => x.toString(16).padStart(2,'0')).join('');
    }
    throw new Error('此瀏覽器缺少安全的請求 ID 產生功能，請使用 HTTPS');
  };

  function status(message,type='') {el.status.textContent=message;el.status.className='status-message '+type;}
  function notify(message,type='') {el.notice.textContent=message;el.notice.className='notice '+type;}
  function stats(id) {
    const prize=state.prizes.find(x=>x.id===id);
    if(!prize) return {total:0,drawn:0,remaining:0};
    const drawn=state.winners.filter(x=>x.prizeId===id).length;
    return {total:prize.quota,drawn,remaining:Math.max(0,prize.quota-drawn)};
  }
  function eligible() {
    const used=new Set(state.winners.map(x=>x.winnerId));
    return state.participants.filter(x=>x.id && !used.has(x.id));
  }
  function setModeText() {
    el.mode.textContent=state.mode==='live' ? '正式模式｜GAS 共用紀錄' : '展示模式｜僅此瀏覽器';
    el.mode.className=state.mode==='live'?'mode live':'mode demo';
    el.historyInfo.textContent=state.mode==='live' ?
      `顯示最近 ${state.history.length} / ${state.historyTotal} 筆；完整紀錄保存於 Google Sheets AuditLogs。` :
      '展示操作僅保存在本瀏覽器，不是正式稽核紀錄。';
  }
  function updateUI() {
    setModeText();
    const current=state.currentPrizeId;
    el.prizeSelect.replaceChildren();
    for (const p of state.prizes) {
      const opt=document.createElement('option');opt.value=p.id;
      const s=stats(p.id);opt.textContent=`${p.name}（剩餘 ${s.remaining}/${s.total}）`;
      el.prizeSelect.appendChild(opt);
    }
    if(current && state.prizes.some(p=>p.id===current)) el.prizeSelect.value=current;
    else state.currentPrizeId=el.prizeSelect.value||'';
    updateStats();renderWinners();renderHistory();
  }
  function updateStats() {
    const p=state.prizes.find(x=>x.id===state.currentPrizeId);
    const s=stats(state.currentPrizeId);
    el.total.textContent=s.total;el.drawn.textContent=s.drawn;el.remaining.textContent=s.remaining;
    el.description.textContent=p ? p.description||'' : '';
    const noPeople=eligible().length===0;
    el.draw.disabled=state.busy || !p || s.remaining<=0 || noPeople;
    el.draw.textContent=state.busy?'處理中…':s.remaining<=0?'該獎項已抽完':noPeople?'無可用名單':'開始抽獎';
    el.reset.disabled=state.busy || !state.winners.length;
    el.refresh.disabled=state.busy || state.mode!=='live';
  }
  function textDiv(className,value) {const div=document.createElement('div');div.className=className;div.textContent=safe(value);return div;}
  function renderWinners() {
    el.winners.replaceChildren();
    if(!state.winners.length){el.winners.append(textDiv('empty-hint','尚無中獎紀錄'));return;}
    for (const p of state.prizes) {
      const items=state.winners.filter(w=>w.prizeId===p.id);
      if(!items.length) continue;
      const block=textDiv('winner-prize-group','');
      block.append(textDiv('group-title',`${p.name}（${items.length} 位）`));
      for (const w of items) {
        const row=document.createElement('div');row.className='winner-item';
        const info=document.createElement('div');
        info.append(textDiv('winner-item-name',w.name||'(名冊已變更)'));
        info.append(textDiv('winner-item-meta',[w.department,w.grade,w.winnerId].filter(Boolean).join(' · ')));
        info.append(textDiv('winner-item-time',formatTime(w.timestamp)));
        row.append(info);
        const cancel=document.createElement('button');cancel.className='btn-sm btn-danger';
        cancel.textContent='取消';cancel.disabled=state.busy;
        cancel.setAttribute('aria-label',`取消 ${w.name||w.winnerId} 的中獎資格`);
        cancel.addEventListener('click',()=>cancelWinner(w));row.append(cancel);block.append(row);
      }
      el.winners.append(block);
    }
  }
  function renderHistory() {
    el.history.replaceChildren();
    const type=el.historyFilter.value;
    const filtered=state.history.filter(ev=>!type||ev.eventType===type);
    if(!filtered.length) {el.history.append(textDiv('empty-hint','目前沒有符合條件的操作紀錄'));return;}
    for(const e of filtered){
      const row=document.createElement('article');row.className='audit-row';
      const header=textDiv('audit-title',`${e.eventType} · ${formatTime(e.timestamp)}`);
      const lines=[e.prizeName||e.prizeId, e.winnerName||e.winnerId].filter(Boolean);
      const info=textDiv('audit-details',lines.join(' ／ ')||'全場操作');
      const change=textDiv('audit-details',`${e.beforeState} → ${e.afterState}${e.reason?' ｜ 原因：'+e.reason:''}`);
      const id=textDiv('audit-id',`事件 ${e.eventId} · 操作者 ${e.actor||'unknown'}`);
      row.append(header,info,change,id);el.history.append(row);
    }
  }
  function demoStore() {try{localStorage.setItem(KEYS.demo,JSON.stringify({winners:state.winners,history:state.history}));}catch(err){notify('展示紀錄無法保存至瀏覽器：'+err.message,'error');}}
  function loadDemo() {
    state.mode='demo';state.token='';state.pendingDraw=null;
    state.prizes=DEMO_DATA.prizes;state.participants=DEMO_DATA.participants;
    state.currentPrizeId=state.prizes[0].id;
    state.winners=[];state.history=[];
    try {
      const saved=JSON.parse(localStorage.getItem(KEYS.demo)||'{}');
      if(Array.isArray(saved.winners)) state.winners=saved.winners;
      if(Array.isArray(saved.history)) state.history=saved.history;
    } catch (_) {}
    state.historyTotal=state.history.length;updateUI();notify('展示模式：記錄只存在這個瀏覽器，不會寫入正式 Google Sheets。');
  }
  async function gasPost(action,values={}) {
    if(state.mode!=='live'||!state.apiUrl||!state.token) throw new Error('尚未連線正式 GAS 或輸入操作密鑰');
    // text/plain JSON is a CORS simple request, avoiding an OPTIONS preflight for GAS.
    const response=await fetch(state.apiUrl,{method:'POST',headers:{'Content-Type':'text/plain;charset=UTF-8'},body:JSON.stringify({action,token:state.token,...values}),redirect:'follow'});
    if(!response.ok) throw new Error('伺服器 HTTP '+response.status);
    const data=await response.json();
    if(data.status!=='success') throw new Error(data.message||'後端操作失敗');
    return data;
  }
  function applySnapshot(data) {
    state.winners=Array.isArray(data.winners)?data.winners:[];
    state.history=Array.isArray(data.history)?data.history:[];
    state.historyTotal=Number(data.historyTotal)||0;
    state.historyLimit=Number(data.historyLimit)||200;
    updateUI();
  }
  async function connect() {
    const url=el.apiUrl.value.trim();const token=el.apiToken.value.trim();
    if(!/^https:\/\/script\.google\.com\/macros\/s\//.test(url)||!url.endsWith('/exec')) {status('請輸入正確的 GAS /exec HTTPS 網址','error');return;}
    if(!token) {status('正式模式需要操作密鑰（GAS Script Properties 中設定的 token）','error');return;}
    el.connect.disabled=true;status('連線並同步正式中獎狀態…');
    try {
      const response=await fetch(url);
      if(!response.ok) throw new Error('名冊讀取 HTTP '+response.status);
      const data=await response.json();
      if(data.status!=='success') throw new Error(data.message||'名冊讀取失敗');
      // Only change mode after authenticated snapshot succeeds. No stale demo winners bleed into live.
      const old={mode:state.mode,apiUrl:state.apiUrl,token:state.token};
      state.mode='live';state.apiUrl=url;state.token=token;
      let snapshot;
      try {snapshot=await gasPost('snapshot');} catch(err){Object.assign(state,old);throw err;}
      state.prizes=data.prizes||[];state.participants=data.participants||[];
      state.currentPrizeId=state.prizes[0]?.id||'';state.pendingDraw=null;
      applySnapshot(snapshot);
      try{localStorage.setItem(KEYS.url,url);}catch(_){}
      // Never persist the privileged token; clearing the field reduces accidental screen exposure.
      el.apiToken.value='';
      el.config.classList.add('hidden');
      status(`正式模式連線成功：${state.participants.length} 名參加者`,'success');
      notify('已同步共用中獎狀態與操作紀錄。正式操作由 GAS 後端執行。','success');
    }catch(err){status('連線失敗：'+err.message,'error');}
    finally{el.connect.disabled=false;}
  }
  async function refresh() {
    if(state.mode!=='live')return;
    state.busy=true;updateStats();
    try {
      const [res,snapshot]=await Promise.all([fetch(state.apiUrl),gasPost('snapshot')]);
      const data=await res.json();if(data.status!=='success')throw new Error(data.message||'名冊同步失敗');
      state.prizes=data.prizes||[];state.participants=data.participants||[];
      applySnapshot(snapshot);notify('正式資料與歷程已同步','success');
    }catch(err){notify('同步失敗：'+err.message,'error');}
    finally{state.busy=false;updateUI();}
  }
  async function animate(pool,prizeName){
    el.rolling.classList.add('rolling');el.rolling.classList.remove('winner-won');
    el.stagePlaceholder.textContent='正在抽取：'+prizeName;
    for(let i=0;i<12;i++){
      const person=pool[Math.floor(Math.random()*pool.length)];
      if(person){el.candidate.textContent=person.name;el.candidateMeta.textContent=[person.department,person.grade].filter(Boolean).join(' · ');}
      await sleep(70);
    }
    el.rolling.classList.remove('rolling');
  }
  function demoEvent(type,winner,reason='',meta={}) {
    return {eventId:uuid(),actionId:uuid(),timestamp:new Date().toISOString(),eventType:type,prizeId:winner?.prizeId||'',winnerId:winner?.winnerId||'',
      prizeName:winner?.prizeName||'',winnerName:winner?.name||'',beforeState:type==='DRAW'?'NOT_WON':type==='CANCEL'?'DRAWN':'ACTIVE:'+state.winners.length,
      afterState:type==='DRAW'?'DRAWN':type==='CANCEL'?'CANCELLED':'ACTIVE:0',reason,actor:'demo',metadataJson:JSON.stringify(meta)};
  }
  async function draw() {
    const prize=state.prizes.find(x=>x.id===state.currentPrizeId);
    const pool=eligible();if(state.busy||!prize||!stats(prize.id).remaining||!pool.length)return;
    state.busy=true;updateStats();notify('抽獎進行中…');
    try {
      await animate(pool,prize.name);
      let win;
      if(state.mode==='live') {
        if(!state.pendingDraw||state.pendingDraw.prizeId!==prize.id)state.pendingDraw={prizeId:prize.id,actionId:uuid()};
        const data=await gasPost('draw',state.pendingDraw);
        applySnapshot(data);
        win=state.winners.find(w=>w.drawEventId===data.lastEvent?.eventId);
        state.pendingDraw=null;
      }else {
        const chosen=pool[Math.floor(Math.random()*pool.length)];
        win={winnerId:chosen.id,name:chosen.name,department:chosen.department,grade:chosen.grade,email:chosen.email,
          prizeId:prize.id,prizeName:prize.name,timestamp:new Date().toISOString(),drawEventId:uuid()};
        state.winners.push(win);
        const event=demoEvent('DRAW',win);event.eventId=win.drawEventId;
        state.history.unshift(event);state.historyTotal++;demoStore();updateUI();
      }
      if(win){el.candidate.textContent=win.name;el.candidateMeta.textContent=[win.department,win.grade,win.winnerId].filter(Boolean).join(' · ');el.stagePlaceholder.textContent='恭喜中獎！';el.rolling.classList.add('winner-won');}
      notify('抽獎成功，操作已'+(state.mode==='live'?'寫入 Google Sheets':'記錄在展示模式'),'success');
    }catch(err){notify('抽獎失敗：'+err.message+'。如遇網路中斷，請先同步確認結果。','error');}
    finally{state.busy=false;updateUI();}
  }
  async function cancelWinner(winner) {
    if(state.busy)return;
    const reason=window.prompt(`確定取消「${winner.name}」的中獎資格？請填寫原因：`);
    if(reason===null)return;
    if(!reason.trim()){notify('取消中獎必須填寫原因','error');return;}
    state.busy=true;updateUI();
    try{
      if(state.mode==='live'){
        const data=await gasPost('cancel',{actionId:uuid(),drawEventId:winner.drawEventId,reason:reason.trim()});applySnapshot(data);
      }else{
        const event=demoEvent('CANCEL',winner,reason.trim(),{drawEventId:winner.drawEventId});
        state.winners=state.winners.filter(w=>w.drawEventId!==winner.drawEventId);
        state.history.unshift(event);state.historyTotal++;demoStore();
      }
      notify('已取消中獎資格；原本的 DRAW 紀錄仍保留','success');
    }catch(err){notify('取消失敗：'+err.message,'error');}
    finally{state.busy=false;updateUI();}
  }
  async function reset() {
    if(state.busy||!state.winners.length)return;
    const reason=window.prompt('重置整場抽獎不會刪除操作歷程。請填寫重置原因：');
    if(reason===null)return;
    if(!reason.trim()){notify('重置必須填寫原因','error');return;}
    if(!window.confirm('確定清空目前中獎狀態？所有舊事件會完整保留。'))return;
    state.busy=true;updateUI();
    try{
      if(state.mode==='live'){
        const data=await gasPost('reset',{actionId:uuid(),reason:reason.trim()});applySnapshot(data);
      }else{
        const event=demoEvent('RESET',null,reason.trim(),{affectedCount:state.winners.length});
        state.winners=[];state.history.unshift(event);state.historyTotal++;demoStore();
      }
      el.candidate.textContent='---';el.candidateMeta.textContent='';el.stagePlaceholder.textContent='準備抽獎';
      el.rolling.classList.remove('winner-won');notify('已重置現況，歷史事件保留','success');
    }catch(err){notify('重置失敗：'+err.message,'error');}
    finally{state.busy=false;updateUI();}
  }
  function csvValue(val) {
    let s=safe(val);
    // Prevent spreadsheet formula injection when exported CSV is opened in Excel/Sheets.
    if(/^[\s\t\r\n]*[=+\-@]/.test(s))s="'"+s;
    return '"'+s.replace(/"/g,'""')+'"';
  }
  function downloadCsv() {
    if(!state.winners.length){notify('沒有中獎者可供匯出','error');return;}
    const columns=['獎品名稱','姓名','系所','年級','學號','電子郵件','中獎時間'];
    const rows=state.winners.map(w=>[w.prizeName,w.name,w.department,w.grade,w.winnerId,w.email,formatTime(w.timestamp)]);
    const text='\uFEFF'+[columns,...rows].map(row=>row.map(csvValue).join(',')).join('\r\n');
    const url=URL.createObjectURL(new Blob([text],{type:'text/csv;charset=utf-8'}));
    const a=document.createElement('a');a.href=url;a.download=`中獎名冊_${new Date().toISOString().slice(0,10)}.csv`;
    document.body.append(a);a.click();a.remove();URL.revokeObjectURL(url);
  }
  function init() {
    Object.assign(el,{
      config:$('config-panel'),status:$('api-status-message'),notice:$('notice'),mode:$('mode-label'),
      apiUrl:$('gas-api-url'),apiToken:$('gas-admin-token'),connect:$('btn-fetch-data'),
      prizeSelect:$('prize-select'),total:$('stat-total-quota'),drawn:$('stat-drawn-count'),remaining:$('stat-remaining-quota'),description:$('prize-desc'),
      draw:$('btn-draw'),reset:$('btn-reset-lottery'),refresh:$('btn-refresh-history'),
      rolling:$('rolling-display'),stagePlaceholder:document.querySelector('.stage-placeholder'),
      candidate:document.querySelector('.winner-candidate-name'),candidateMeta:document.querySelector('.winner-candidate-meta'),
      winners:$('winners-list-container'),history:$('audit-list'),historyFilter:$('history-filter'),historyInfo:$('history-info')
    });
    $('btn-toggle-config').addEventListener('click',()=>el.config.classList.toggle('hidden'));
    $('btn-close-config').addEventListener('click',()=>el.config.classList.add('hidden'));
    $('btn-load-demo').addEventListener('click',loadDemo);
    el.connect.addEventListener('click',connect);
    el.prizeSelect.addEventListener('change',()=>{state.currentPrizeId=el.prizeSelect.value;updateStats();});
    el.draw.addEventListener('click',draw);el.reset.addEventListener('click',reset);
    el.refresh.addEventListener('click',refresh);$('btn-export-csv').addEventListener('click',downloadCsv);
    el.historyFilter.addEventListener('change',renderHistory);
    try{el.apiUrl.value=localStorage.getItem(KEYS.url)||'';}catch(_){}
    loadDemo();
  }
  window.__lotterySystem={state,loadDemo,stats,eligible};
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init); else init();
})();
